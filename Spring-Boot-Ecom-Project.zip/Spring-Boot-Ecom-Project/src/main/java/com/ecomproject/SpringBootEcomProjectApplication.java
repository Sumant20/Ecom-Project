package com.ecomproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEcomProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEcomProjectApplication.class, args);
	}

}
